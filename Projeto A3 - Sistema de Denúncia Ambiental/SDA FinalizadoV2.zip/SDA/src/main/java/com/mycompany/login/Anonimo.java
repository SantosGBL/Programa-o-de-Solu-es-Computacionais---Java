package com.mycompany.login;

public class Anonimo {
    private String nome;
    private int numero;
    private String email;

    public Anonimo(String nome, int numero, String email) {
        this.nome = nome;
        this.numero = numero;
        this.email = email;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
