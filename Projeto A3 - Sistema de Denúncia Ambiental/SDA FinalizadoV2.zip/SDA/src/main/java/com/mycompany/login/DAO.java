package com.mycompany.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
    public boolean existe (Usuario usuario) throws Exception{ 
     String sql = "SELECT * FROM tb_usuario WHERE login = ? AND senha  = ?"; 
     try (Connection conn = ConexaoBD.obtemConexao(); 
     PreparedStatement ps = conn.prepareStatement(sql)){ 
        ps.setString(1, usuario.getLogin()); 
        ps.setString(2, usuario.getSenha()); 
        try (ResultSet rs = ps.executeQuery()){ 
            return rs.next(); 
        }
     } 
   }
        public void adicionarAnonimo (Anonimo anonimo) throws Exception{
        String sql = "INSERT INTO tb_cadastro (nome,numero,email) VALUES (?,?,?);";
        try (Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1,anonimo.getNome());
            ps.setInt(2, anonimo.getNumero());
            ps.setString(3, anonimo.getEmail());
            ps.execute();
        }
    }
    public void adicionarCadastro (Cadastro cadastro) throws Exception{
        String sql = "INSERT INTO tb_cadastro (nome, numero, email) values (?,?,?)";
        try (Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, cadastro.getNome());
            ps.setInt(2, cadastro.getNumero());
            ps.setString(3, cadastro.getEmail());
            ps.execute();
        }
    }
    public void adicionar (Denuncia denuncia) throws Exception{
       String sql = "INSERT INTO tb_denuncias (estado,cidade,referencia,categoria_denuncia,descricao) values (?,?,?,?,?)";
       try (Connection conn = ConexaoBD.obtemConexao();
               PreparedStatement ps = conn.prepareStatement(sql)){
           ps.setString(1, denuncia.getEstado());
           ps.setString(2, denuncia.getCidade());
           ps.setString(3, denuncia.getReferencia());
           ps.setString(4, denuncia.getClassificacao());
           ps.setString(5, denuncia.getDescricao());
           ps.execute();
       }
    }
        public void atualizar (Denuncia denuncia) throws Exception{
       String sql = "UPDATE tb_denuncias set estado = ?, cidade = ?, referencia = ?, categoria_denuncia = ?, descricao = ? WHERE id = ?;";
       try (Connection conn = ConexaoBD.obtemConexao();
               PreparedStatement ps = conn.prepareStatement(sql)){
           ps.setString(1, denuncia.getEstado());
           ps.setString(2, denuncia.getCidade());
           ps.setString(3, denuncia.getReferencia());
           ps.setString(4, denuncia.getClassificacao());
           ps.setString(5, denuncia.getDescricao());
           ps.setInt(6, denuncia.getId());
           ps.execute();
       }
    }
        public void remover(Denuncia denuncia) throws Exception{
            String sql = "DELETE FROM tb_denuncias WHERE id = ?";
            try (Connection conn = ConexaoBD.obtemConexao();
                    PreparedStatement ps = conn.prepareStatement(sql)){
                ps.setInt(1, denuncia.getId());
                ps.execute();
            }
        }
        public void criarConta (Usuario usuario) throws Exception{
        String sql = "INSERT INTO tb_usuario (login,senha) VALUES (?,?);";
        try (Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getSenha());
            ps.execute();
        }
    }
}
    


    