
package com.mycompany.login;

public class Denuncia {
    private String estado;
    private String cidade;
    private String referencia;
    private String classificacao;
    private String descricao;
    private int id;
    
    public Denuncia(int id, String estado,String cidade, String referencia,String classificacao, String descricao){
        this.estado = estado;
        this.cidade = cidade;
        this.referencia = referencia;
        this.classificacao = classificacao;
        this.descricao = descricao;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    } 
}
